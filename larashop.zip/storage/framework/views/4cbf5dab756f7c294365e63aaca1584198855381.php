<?php $__env->startSection('title'); ?>
    Edit User
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-8">
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('users.update', [$user->id])); ?>" class="bg-white shadow-sm p-3" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="_method" value="PUT">
        <label for="name">Name</label>
        <input class="form-control" type="text" name="name" id="name" placeholder="Full Name" value="<?php echo e($user->name); ?>">
        <br>
        <label for="username">username</label>
        <input type="text" name="username" id="username" class="form-control" placeholder="username" value="<?php echo e($user->username); ?>" disabled>
        <br>
        <label for="">Status</label>
        <br>
        <input <?php echo e($user->status == "ACTIVE" ? "checked" : ""); ?> value="ACTIVE" type="radio" class="form-control" id="active" name="status">
        <label for="active">Active</label>
        <input <?php echo e($user->status == "INACTIVE" ? "checked" : ""); ?> value="INACTIVE" type="radio" class="form-control" id="inactive" name="status">
        <label for="inactive">Inactive</label>
        <br><br>
        <label for="">Roles</label>
        <br>
        <input type="checkbox" <?php echo e(in_array("ADMIN", json_decode($user->roles)) ? "checked" : ""); ?> name="roles[]" id="ADMIN" value="ADMIN">
        <label for="ADMIN">Administrator</label>
        <input type="checkbox" <?php echo e(in_array("STAFF", json_decode($user->roles)) ? "checked" : ""); ?> name="roles[]" id="STAFF" value="STAFF">
        <label for="STAFF">Staff</label>
        <input type="checkbox" <?php echo e(in_array("CUSTOMER", json_decode($user->roles)) ? "checked" : ""); ?> name="roles[]" id="CUSTOMER" value="CUSTOMER">
        <label for="CUSTOMER">Customer</label>
        <br>
        <br>
        <label for="phone">Phone number</label>
        <br>
        <input type="text" name="phone" class="form-control" value="<?php echo e($user->phone); ?>">
        <br>
        <label for="address">Address</label>
        <textarea name="address" id="address" class="form-control"><?php echo e($user->address); ?></textarea>
        <br>
        <label for="avatar">Avatar image</label>
        <br>
        Current avatar: <br>
        <?php if($user->avatar): ?>
            <img src="<?php echo e(asset('storage/'.$user->avatar)); ?>" alt="avatar" width="120px">
        <?php else: ?>
            No Avatar
        <?php endif; ?>
        <br>
        <input type="file" class="form-control" name="avatar" id="avatar">
        <small class="text-muted">Kosongkan jika tidak ingin mengubah avatar</small>
        <hr class="my-3">
        <label for="email">Email</label>
        <input type="text" name="email" id="email" placeholder="user@email.com" value="<?php echo e($user->email); ?>" disabled>
        <br>
        <input class="btn btn-primary" type="submit" value="Save">
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mutaqin/Codebattlefield/laravel/toko-online/resources/views/users/edit.blade.php ENDPATH**/ ?>