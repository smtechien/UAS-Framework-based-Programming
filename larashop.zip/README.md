## UAS Framework-based Programming
_dibuat menggunakan Laravel 8_

<table>
  <tr>
    <th>Nama</th>
    <td>Sulthon Mutaqin Rahmatullah</td>
  </tr>
  <tr>
    <th>NIM</th>
    <td>1915026026</td>
  </tr>
</table>

### Fitur yang dibuat: Manage User
